from machine import Pin
import time

led_vermelho = Pin(21, Pin.OUT)
led_amarelo = Pin(19, Pin.OUT)
led_verde = Pin(18, Pin.OUT)

def desligar_todos():
    led_vermelho.value(0)
    led_amarelo.value(0)
    led_verde.value(0)

while True:

    desligar_todos()
    led_vermelho.value(1)
    time.sleep(5)
    
    desligar_todos()
    led_verde.value(1)
    time.sleep(5)
    
    desligar_todos()
    led_amarelo.value(1)
    time.sleep(2)