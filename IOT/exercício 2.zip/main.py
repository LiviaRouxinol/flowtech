from machine import Pin
from time import sleep

botao = Pin(12, Pin.IN, Pin.PULL_UP)
led = Pin(23, Pin.OUT)

while True:
    if botao.value() == 0:  
        led.value(1)
    else:
        led.value(0)

    sleep(0.01)