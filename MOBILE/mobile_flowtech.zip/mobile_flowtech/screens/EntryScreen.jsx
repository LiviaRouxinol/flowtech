import React, { useState, useEffect } from 'react';

import {
  View, //tipo uma diva
  Text, //texto 
  StyleSheet, //cria e organiza regras de estilização (tipo CSS)
  TouchableOpacity, //botao que diminui a ocapacidade
  TextInput, //funciona como o input comum
  ScrollView, //permiti o usuario a rolar quando o conteudo é maior que o visor
  Alert,
} from 'react-native';

import { Ionicons } from '@expo/vector-icons'; //conjunto de icones prontos personalizaveis
import api from '../src/services/api';


export default function EntryScreen() {
  // 1. Estado para armazenar os dados do produto vindo do Banco de Dados
  const [dadosDoProduto, setDadosDoProduto] = useState(null);

  // 2. Estados do formulário de entrada (Alinhados com as colunas do seu banco)
  const [code, setCode] = useState('');
  const [quantidade, setQuantidade] = useState('');
  const [fornecedorNome, setFornecedorNome] = useState(''); // Texto para a tela
  const [status, setStatus] = useState('Em andamento');    // Alinhado ao 'status_pedido'
  const [descricao, setDescricao] = useState('');          // Alinhado ao 'descricao'
  const [precoCusto, setPrecoCusto] = useState('');        // Alinhado ao 'preco_custo'
  const [funcionarioNome, setFuncionarioNome] = useState(''); // Texto para a tela

  // 3. IDs Fixos temporários para respeitar os campos INT NOT NULL das chaves estrangeiras
  const FORNECEDOR_ID_PADRAO = 1;
  const FUNCIONARIO_ID_PADRAO = 1;

  // 4. Função para buscar o produto no banco pelo ID do produto
  const carregarProdutoDoBanco = async (idProduto) => {
    try {
      const response = await api.get(`/produtos/${idProduto}`);
      if (response.data) {
        setDadosDoProduto(response.data);
        // Salva o RFID do banco se ele existir, ou usa o ID como código
        setCode(response.data.RFID || String(response.data.produto_id));
      }
    } catch (error) {
      console.error("Erro ao buscar produto do banco:", error);
      Alert.alert("Erro", "Não foi possível carregar as informações do produto.");
    }
  };

  // Carrega automaticamente o produto ID 1 ao entrar na tela para fins de teste
  useEffect(() => {
    carregarProdutoDoBanco(1);
  }, []);

  // 5. Função para salvar o Pedido de Entrada e os Itens ao mesmo tempo
  const handleSalvarEntrada = async () => {
    // Validação de campos obrigatórios do formulário
    if (!quantidade || !precoCusto || !descricao) {
      Alert.alert("Campos vazios", "Por favor, preencha a quantidade, o preço de custo e a descrição!");
      return;
    }

    if (!dadosDoProduto) {
      Alert.alert("Produto ausente", "Nenhum produto foi carregado para dar entrada.");
      return;
    }

    try {
      // Gera a data e hora no formato padrão que o MySQL aceita: 'YYYY-MM-DD HH:MM:SS'
      const dataHoraAtual = new Date().toISOString().slice(0, 19).replace('T', ' ');

      // Envia o pacote completo esperado pela nova rota unificada do backend
      const response = await api.post('/pedido-entrada', {
        data_hora: dataHoraAtual,
        descricao: descricao,
        status_pedido: status,
        fornecedor_id: FORNECEDOR_ID_PADRAO, // Envia o ID numérico exigido pela tabela pai
        estoque_id: null,
        funcionario_id: FUNCIONARIO_ID_PADRAO, // Envia o ID numérico exigido pela tabela pai
        rfid: code,
        local_id: null,

        // Campos que o backend vai extrair e salvar na tabela itempedido_entrada
        produto_id: dadosDoProduto.produto_id,
        preco_custo: parseFloat(String(precoCusto).replace(',', '.')),
        quantidade: parseInt(quantidade)
      });

      if (response.data && response.data.success === true) {
        Alert.alert("Sucesso", "Entrada de estoque cadastrada com sucesso!");
        // Limpa os campos numéricos após salvar
        setQuantidade('');
        setPrecoCusto('');
        setDescricao('');
      }

    } catch (error) {
      console.error("Erro ao salvar entrada:", error);
      Alert.alert("Erro de Cadastro", error.response?.data?.message || "Não foi possível salvar os dados no servidor.");
    }
  };

  const qtd = parseFloat(quantidade) || 0;
  const precoLimpo = precoCusto ? String(precoCusto).replace(',', '.') : '0';
  const preco = parseFloat(precoLimpo) || 0;
  const valorTotal = qtd * preco;

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
      <View style={{ height: 40 }} />

      {/* HEADER */}
      <View style={styles.header}>
        <Text style={styles.title}>Entrada de Estoque</Text>
        <Text style={styles.subtitle}>Registre produtos rapidamente</Text>
      </View>

      {/* QR CODE */}
      <TouchableOpacity style={styles.qrButton} onPress={() => carregarProdutoDoBanco(1)}>
        <View style={styles.qrContent}>
          <Ionicons name="qr-code-outline" size={32} color="#fff" />
          <View>
            <Text style={styles.qrTitle}>Ler QR Code</Text>
            <Text style={styles.qrSubtitle}>Escanear produto</Text>
          </View>
        </View>
        <Ionicons name="chevron-forward" size={22} color="#fff" />
      </TouchableOpacity>

      {/* CARD PRODUTO ENCONTRADO */}
      <Text style={styles.sectionTitle}>Produto Encontrado</Text>
      <View style={styles.productCard}>
        <View style={styles.productIcon}>
          <Ionicons name="cube" size={28} color="#3B82F6" />
        </View>
        <View style={{ flex: 1 }}>
          <Text style={styles.productName}>
            {dadosDoProduto ? dadosDoProduto.nome : 'Buscando produto do banco...'}
          </Text>
          <Text style={styles.productCode}>Código: {code || '---'}</Text>
          <Text style={styles.productStock}>
            Estoque Mínimo Cadastrado: {dadosDoProduto ? dadosDoProduto.estoque_minimo : '---'}
          </Text>
        </View>
      </View>

      {/* PEDIDO ENTRADA */}
      <View style={styles.summaryCard}>
        <Text style={styles.summaryTitle}>Pedido Entrada</Text>

        <Text style={styles.sectionTitle}>Fornecedor</Text>
        <TextInput
          style={styles.input}
          placeholder="Digite o nome do fornecedor"
          placeholderTextColor="#94A3B8"
          value={fornecedorNome}
          onChangeText={setFornecedorNome}
        />

        <Text style={styles.sectionTitle}>Descrição do Pedido *</Text>
        <TextInput
          style={[styles.input, { height: 80, textAlignVertical: 'top' }]}
          placeholder="Escreva a descrição aqui..."
          multiline={true}
          placeholderTextColor="#94A3B8"
          value={descricao}
          onChangeText={setDescricao}
        />

        <Text style={styles.sectionTitle}>Status do Pedido</Text>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginTop: 10 }}>
          {['Em andamento', 'Finalizado', 'Cancelado'].map((opcao) => (
            <Text
              key={opcao}
              onPress={() => setStatus(opcao)}
              style={[
                styles.input,
                {
                  flex: 1,
                  marginHorizontal: 4,
                  textAlign: 'center',
                  borderRadius: 8,
                  fontSize: 12,
                  backgroundColor: status === opcao ? '#22C55E' : '#1E293B',
                  color: status === opcao ? '#FFFFFF' : '#94A3B8'
                }
              ]}
            >
              {opcao}
            </Text>
          ))}
        </View>

        <Text style={styles.sectionTitle}>Funcionário</Text>
        <TextInput
          style={styles.input}
          placeholder="Digite o nome do funcionário"
          placeholderTextColor="#94A3B8"
          value={funcionarioNome}
          onChangeText={setFuncionarioNome}
        />
      </View>

      {/* ITENS DO PEDIDO ENTRADA */}
      <View style={styles.summaryCard}>
        <Text style={styles.summaryTitle}>Itens do Pedido Entrada</Text>

        <Text style={styles.sectionTitle}>Preço de Custo *</Text>
        <TextInput
          style={styles.input}
          placeholder="Ex: 5,50"
          placeholderTextColor="#94A3B8"
          keyboardType="decimal-pad"
          value={precoCusto}
          onChangeText={setPrecoCusto}
        />

        <Text style={styles.sectionTitle}>Quantidade *</Text>
        <TextInput
          style={styles.input}
          placeholder="Ex: 10"
          placeholderTextColor="#94A3B8"
          keyboardType="number-pad"
          value={quantidade}
          onChangeText={setQuantidade}
        />

        {/* EXIBIÇÃO DO VALOR TOTAL TOTAL */}
        <View style={{ marginTop: 15, borderTopWidth: 1, borderColor: '#334155', paddingTop: 15 }}>
          <Text style={{ color: '#94A3B8', fontSize: 14 }}>Valor Total Estimado:</Text>
          <Text style={{ color: '#22C55E', fontSize: 24, fontWeight: 'bold' }}>
            R$ {valorTotal.toFixed(2).replace('.', ',')}
          </Text>
        </View>
      </View>

      {/* BOTÃO SALVAR */}
      <TouchableOpacity style={styles.saveButton} onPress={handleSalvarEntrada}>
        <Text style={styles.saveButtonText}>Confirmar Entrada de Estoque</Text>
      </TouchableOpacity>
      
      <View style={{ height: 40 }} />
    </ScrollView>
  );
}

// 🎨 ESTILIZAÇÃO DO LAYOUT
const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0F172A', paddingHorizontal: 16 },
  scrollContent: { paddingBottom: 20 },
  header: { marginBottom: 20 },
  title: { fontSize: 24, fontWeight: 'bold', color: '#FFF' },
  subtitle: { fontSize: 14, color: '#94A3B8' },
  qrButton: { flexDirection: 'row', backgroundColor: '#3B82F6', padding: 16, borderRadius: 12, alignItems: 'center', justifyContent: 'space-between', marginBottom: 20 },
  qrContent: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  qrTitle: { color: '#FFF', fontSize: 16, fontWeight: 'bold' },
  qrSubtitle: { color: '#E2E8F0', fontSize: 12 },
  sectionTitle: { color: '#94A3B8', fontSize: 14, fontWeight: '600', marginTop: 15, marginBottom: 8 },
  productCard: { flexDirection: 'row', backgroundColor: '#1E293B', padding: 16, borderRadius: 12, alignItems: 'center', gap: 12, marginBottom: 15 },
  productIcon: { backgroundColor: '#1E3A8A', padding: 10, borderRadius: 8 },
  productName: { color: '#FFF', fontSize: 16, fontWeight: 'bold' },
  productCode: { color: '#94A3B8', fontSize: 13 },
  productStock: { color: '#F59E0B', fontSize: 13, marginTop: 4 },
  summaryCard: { backgroundColor: '#1E293B', padding: 16, borderRadius: 12, marginBottom: 15 },
  summaryTitle: { color: '#FFF', fontSize: 16, fontWeight: 'bold', borderBottomWidth: 1, borderColor: '#334155', paddingBottom: 8 },
  input: { backgroundColor: '#0F172A', color: '#FFF', padding: 12, borderRadius: 8, fontSize: 14, marginTop: 5 },
  saveButton: { backgroundColor: '#22C55E', padding: 16, borderRadius: 12, alignItems: 'center', marginTop: 10 },
  saveButtonText: { color: '#FFF', fontSize: 16, fontWeight: 'bold' }
});