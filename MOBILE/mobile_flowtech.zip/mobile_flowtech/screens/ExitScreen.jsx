import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  ScrollView,
  Alert,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import api from '../src/services/api';

export default function ExitScreen() {
  // 1. Estados para os dados vindos da tabela 'produto' do MySQL
  const [dadosDoProduto, setDadosDoProduto] = useState(null);
  const [code, setCode] = useState('');

  // 2. Estados dos formulários (Alinhados com a estrutura do seu banco)
  const [quantidade, setQuantidade] = useState('');
  const [destinoCliente, setDestinoCliente] = useState(''); // Armazena texto provisório
  const [status, setStatus] = useState('Em andamento');      // Alinhado ao 'status_pedido'
  const [descricao, setDescricao] = useState('');            // Alinhado ao 'descricao'
  const [precoVenda, setPrecoVenda] = useState('');          // Alinhado ao 'preco_venda'
  const [funcionarioNome, setFuncionarioNome] = useState(''); // Armazena texto provisório

  // 3. IDs Padrões numéricos exigidos como NOT NULL pelas Chaves Estrangeiras do MySQL
  const CLIENTE_ID_PADRAO = 1;
  const ESTOQUE_ID_PADRAO = 1;
  const FUNCIONARIO_ID_PADRAO = 1;

  // 4. Carrega o produto ID 1 do banco ao iniciar para testes
  const carregarProdutoDoBanco = async (idProduto) => {
    try {
      const response = await api.get(`/produtos/${idProduto}`);
      if (response.data) {
        setDadosDoProduto(response.data);
        setCode(response.data.RFID || String(response.data.produto_id));
      }
    } catch (error) {
      console.error("Erro ao buscar produto do banco:", error);
      Alert.alert("Erro", "Não foi possível carregar o produto.");
    }
  };

  useEffect(() => {
    carregarProdutoDoBanco(1);
  }, []);

  // 5. Função para enviar a Saída Completa (Duas tabelas) para o Backend
  const handleConfirmarSaida = async () => {
    if (!quantidade || !precoVenda || !descricao) {
      Alert.alert("Campos vazios", "Por favor, preencha a quantidade, o preço de venda e a descrição!");
      return;
    }

    if (!dadosDoProduto) {
      Alert.alert("Erro", "Nenhum produto selecionado.");
      return;
    }

    try {
      // Formato DATETIME esperado pelo MySQL: 'YYYY-MM-DD HH:MM:SS'
      const dataHoraAtual = new Date().toISOString().slice(0, 19).replace('T', ' ');

      const response = await api.post('/pedido-saida', {
        data_hora: dataHoraAtual,
        status_pedido: status,
        descricao: descricao,
        rfid: code,
        cliente_id: CLIENTE_ID_PADRAO,
        local_id: null,
        estoque_id: ESTOQUE_ID_PADRAO,
        funcionario_id: FUNCIONARIO_ID_PADRAO,
        
        // Dados para a tabela filha: itempedido_saida
        quantidade: parseInt(quantidade),
        preco_venda: parseFloat(precoVenda.replace(',', '.')),
        produto_id: dadosDoProduto.produto_id
      });

      if (response.data && response.data.success === true) {
        Alert.alert("Sucesso", "Saída de estoque registrada perfeitamente!");
        setQuantidade('');
        setPrecoVenda('');
        setDescricao('');
      }

    } catch (error) {
      console.error("Erro ao salvar saída:", error);
      Alert.alert("Erro", error.response?.data?.message || "Não foi possível registrar no banco.");
    }
  };

  // Cálculos dinâmicos do resumo da tela
  const qtdDigitada = parseInt(quantidade) || 0;
  const estoqueAtualBanco = dadosDoProduto ? dadosDoProduto.estoque_minimo : 15; // Exemplo usando estoque cadastrado
  const precovendaNum = parseFloat(precoVenda.replace(',', '.')) || 0;

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.scrollContent}>
      <Text style={styles.title}>Saída de Estoque</Text>

      <TouchableOpacity style={styles.qrButton} onPress={() => carregarProdutoDoBanco(1)}>
        <Ionicons name="qr-code-outline" size={28} color="#fff" />
        <Text style={styles.qrText}>Escanear Produto</Text>
      </TouchableOpacity>

      {/* PRODUTO */}
      <Text style={styles.sectionTitle}>Produto Encontrado</Text>

      <View style={styles.productCard}>
        <View style={styles.productIcon}>
          <Ionicons name="cube" size={28} color="#3B82F6" />
        </View>
        <Text style={[styles.productName, { marginTop: 10, textAlign: 'center' }]}>
          {dadosDoProduto ? dadosDoProduto.nome : 'Carregando...'}
        </Text>
        <Text style={[styles.stock, { textAlign: 'center' }]}>
          Estoque Atual: {estoqueAtualBanco}
        </Text>
      </View>

      {/* PEDIDO SAÍDA */}
      <View style={styles.summaryCard}>
        <Text style={styles.summaryTitle}>Pedido Saída</Text>

        {/* DESTINO */}
        <Text style={styles.sectionTitle}>Destino / Cliente</Text>
        <TextInput
          style={styles.input}
          placeholder="Digite o destino ou nome do cliente"
          placeholderTextColor="#94A3B8"
          value={destinoCliente}
          onChangeText={setDestinoCliente}
        />

        {/* DESCRIÇÃO */}
        <Text style={styles.sectionTitle}>Descrição *</Text>
        <TextInput
          style={[styles.input, { height: 100, textAlignVertical: 'top' }]}
          placeholder="Escreva o motivo da saída obrigatório aqui..."
          multiline={true}
          placeholderTextColor="#94A3B8"
          value={descricao}
          onChangeText={setDescricao}
        />

        {/* STATUS PEDIDO */}
        <Text style={styles.sectionTitle}>Status do Pedido</Text>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginTop: 10 }}>
          {['Em andamento', 'Finalizado', 'Cancelado'].map((opcao) => (
            <TouchableOpacity
              key={opcao}
              onPress={() => setStatus(opcao)}
              style={[
                styles.statusTabButton,
                { backgroundColor: status === opcao ? '#22C55E' : '#1E293B' }
              ]}
            >
              <Text style={{ color: status === opcao ? '#FFFFFF' : '#94A3B8', fontWeight: 'bold', fontSize: 13 }}>
                {opcao}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* FUNCIONÁRIO */}
        <Text style={styles.sectionTitle}>Funcionário</Text>
        <TextInput
          style={styles.input}
          placeholder="Digite o nome do funcionário"
          placeholderTextColor="#94A3B8"
          value={funcionarioNome}
          onChangeText={setFuncionarioNome}
        />
      </View>

      {/* ITENS PEDIDO SAÍDA */}
      <View style={styles.summaryCard}>
        <Text style={styles.summaryTitle}>Itens do Pedido Saída</Text>

        {/* PREÇO DE VENDA */}
        <Text style={styles.sectionTitle}>Preço de Venda *</Text>
        <TextInput
          style={styles.input}
          placeholder="Ex: 35,00"
          placeholderTextColor="#94A3B8"
          keyboardType="decimal-pad"
          value={precoVenda}
          onChangeText={setPrecoVenda}
        />

        {/* QUANTIDADE */}
        <Text style={styles.sectionTitle}>Quantidade *</Text>
        <TextInput
          style={styles.input}
          placeholder="Digite a quantidade de saída"
          placeholderTextColor="#94A3B8"
          keyboardType="numeric"
          value={quantidade}
          onChangeText={setQuantidade}
        />
      </View>

      {/* RESUMO */}
      <View style={styles.summaryCard}>
        <Text style={styles.summaryTitle}>Resumo da Saída</Text>

        <View style={styles.summaryRow}>
          <Text style={styles.summaryLabel}>Produto</Text>
          <Text style={styles.summaryValue}>{dadosDoProduto ? dadosDoProduto.nome : 'Nenhum'}</Text>
        </View>

        <View style={styles.summaryRow}>
          <Text style={styles.summaryLabel}>Quantidade</Text>
          <Text style={styles.summaryValue}>{qtdDigitada}</Text>
        </View>

        <View style={styles.resultCard}>
          <Text style={styles.resultText}>Estoque Restante</Text>
          <Text style={[styles.resultValue, { color: (estoqueAtualBanco - qtdDigitada) < 0 ? '#EF4444' : '#22C55E' }]}>
            {estoqueAtualBanco - qtdDigitada}
          </Text>
        </View>

        <View style={styles.summaryRow}>
          <Text style={styles.summaryLabel}>Valor Total do Pedido:</Text>
          <Text style={[styles.summaryValue, { color: '#22C55E', fontSize: 16 }]}>
            R\$ {(precovendaNum * qtdDigitada).toFixed(2).replace('.', ',')}
          </Text>
        </View>
      </View>

      {/* BOTÃO DE CONFIRMAÇÃO COM ACIONADOR DA COOPERAÇÃO COM O BACKEND */}
      <TouchableOpacity style={styles.confirmButton} onPress={handleConfirmarSaida}>
        <Ionicons name="remove-circle" size={24} color="#fff" />
        <Text style={styles.confirmText}>Confirmar Saída </Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#020617',
    paddingHorizontal: 20,
  },
  scrollContent: {
    paddingBottom: 60, // Impede que o botão fique embutido atrás da barra de navegação
  },
  title: {
    color: '#fff',
    fontSize: 28,
    fontWeight: 'bold',
    marginTop: 40,
    marginBottom: 20,
  },
  qrButton: {
    backgroundColor: '#DC2626',
    height: 60,
    borderRadius: 16,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 10,
    marginBottom: 10,
  },
  qrText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  productCard: {
    backgroundColor: '#1E293B',
    borderRadius: 16,
    padding: 20,
    marginTop: 10,
  },
  productIcon: {
    alignItems: 'center',
  },
  productName: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
  stock: {
    color: '#FCA5A5',
    marginTop: 6,
    fontWeight: 'bold',
    fontSize: 14,
  },
  sectionTitle: {
    color: '#94A3B8',
    fontSize: 13,
    fontWeight: 'bold',
    textTransform: 'uppercase',
    marginTop: 16,
    marginBottom: 6,},input: {backgroundColor: '#1E293B',height: 50,borderRadius: 10,paddingHorizontal: 15,color: '#fff',fontSize: 15,marginBottom: 5,},summaryCard: {backgroundColor: '#1E293B',borderRadius: 16,padding: 20,marginTop: 15,},summaryTitle: {color: '#fff',fontSize: 16,fontWeight: 'bold',marginBottom: 5,},statusTabButton: {flex: 1,height: 40,marginHorizontal: 4,borderRadius: 8,justifyContent: 'center',alignItems: 'center',},summaryRow: {flexDirection: 'row',justifyContent: 'space-between',marginVertical: 4,},summaryLabel: {color: '#94A3B8',fontSize: 14,},summaryValue: {color: '#fff',fontSize: 14,fontWeight: 'bold',},resultCard: {backgroundColor: '#0F172A',padding: 12,borderRadius: 10,marginVertical: 8,flexDirection: 'row',justifyContent: 'space-between',alignItems: 'center',},resultText: {color: '#fff',fontSize: 14,},resultValue: {fontSize: 16,fontWeight: 'bold',},confirmButton: {backgroundColor: '#DC2626',height: 55,borderRadius: 12,flexDirection: 'row',justifyContent: 'center',alignItems: 'center',gap: 10,marginTop: 25,marginBottom: 30,},confirmText: {color: '#fff',fontSize: 16,fontWeight: 'bold',},});