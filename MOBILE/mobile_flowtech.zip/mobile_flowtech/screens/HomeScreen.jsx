import React, { useState, useEffect } from 'react';

import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  ActivityIndicator, // Adicionado para dar feedback visual de carregamento
} from 'react-native';

import { Ionicons } from '@expo/vector-icons';

export default function HomeScreen({ navigation }) {
  // 1. Estados para armazenar os dados vindos do banco
  const [totalProdutos, setTotalProdutos] = useState(0);
  const [estoqueBaixo, setEstoqueBaixo] = useState(0);
  const [carregando, setCarregando] = useState(true);
  const [atividades, setAtividades] = useState([]);

  // 2. Efeito para buscar os dados assim que a tela abrir
  useEffect(() => {
    async function buscarDadosDoBanco() {
      try {
        // CORREÇÃO: Adicionada explicitamente a rota /api/dashboard no final da URL
        const resposta = await fetch('http://10.135.60');
        
        if (!resposta.ok) {
          throw new Error(`Erro na requisição: Código ${resposta.status}`);
        }
        
        const dados = await resposta.json();
        print ('Dadosss',dados)

        setTotalProdutos(dados.totalProducts || 0);
        setEstoqueBaixo(dados.lowStockCount || 0);
        setAtividades(dados.atividades || []); 
      } catch (error) {
        console.error("Erro ao buscar dados do estoque:", error);
      } finally {
        setCarregando(false);
      }
    }

    buscarDadosDoBanco();
  }, []); 


  return (
    <ScrollView
      style={styles.container}
      showsVerticalScrollIndicator={false}
    >
      {/* HEADER */}
      <View style={styles.header}>
        <View style={styles.headerCenter}>
          <Text style={styles.welcome}>
            Bem-vindo
          </Text>

          <Text style={styles.userName}>
            Flow Tech
          </Text>
        </View>

        <TouchableOpacity style={styles.notification}>
          <Ionicons
            name="notifications-outline"
            size={24}
            color="#fff"
          />
        </TouchableOpacity>
      </View>

      {/* DASHBOARD */}
      <View style={styles.balanceCard}>
        <Text style={styles.balanceLabel}>
          Produtos em Estoque
        </Text>

        <Text style={styles.balanceValue}>
          {carregando ? (
            <ActivityIndicator color="#fff" size="small" />
          ) : (
            totalProdutos
          )}
        </Text>

        <View style={styles.balanceFooter}>
          <Ionicons
            name="trending-up"
            size={18}
            color="#22C55E"
          />
        </View>
      </View>

      {/* CARDS */}
      <View style={styles.cardsContainer}>
        <View style={styles.smallCard}>
          <View style={styles.iconBlue}>
            <Ionicons
              name="layers"
              size={24}
              color="#ffffff"
            />
          </View>

          <Text style={styles.cardNumber}>
            {carregando ? "..." : totalProdutos}
          </Text>

          <Text style={styles.cardLabel}>
            Produtos
          </Text>
        </View>

        <View style={styles.smallCard}>
          <View style={styles.iconRed}>
            <Ionicons
              name="trending-down"
              size={24}
              color="#EF4444"
            />
          </View>

          <Text style={styles.cardNumber}>
            {carregando ? "..." : estoqueBaixo}
          </Text>

          <Text style={styles.cardLabel}>
            Estoque Baixo
          </Text>
        </View>
      </View>

      {/* MENU */}
      <Text style={styles.sectionTitle}>
        Operações
      </Text>

      <TouchableOpacity
        style={styles.actionButtonBlue}
        onPress={() => navigation.navigate('Produtos')}
      >
        <View style={styles.buttonContent}>
          <Ionicons
            name="cube-outline"
            size={26}
            color="#fff"
          />

          <View>
            <Text style={styles.buttonTitle}>
              Produtos
            </Text>

            <Text style={styles.buttonSubtitle}>
              Visualizar estoque completo
            </Text>
          </View>
        </View>

        <Ionicons
          name="chevron-forward"
          size={22}
          color="#fff"
        />
      </TouchableOpacity>

      <TouchableOpacity
        style={styles.actionButtonYellow}
        onPress={() => navigation.navigate('Movimentacao')}
      >
        <View style={styles.buttonContent}>
          <Ionicons
            name="git-compare-outline"
            size={26}
            color="#fff"
          />

          <View>
            <Text style={styles.buttonTitle}>
              Movimentação
            </Text>

            <Text style={styles.buttonSubtitle}>
              Entrada e Saída
            </Text>
          </View>
        </View>

        <Ionicons
          name="chevron-forward"
          size={22}
          color="#fff"
        />
      </TouchableOpacity>

      {/* ATIVIDADES RECENTES */}
      <Text style={styles.sectionTitle}>Atividades Recentes</Text>

      {atividades.length === 0 ? (
        <Text style={{ color: '#94A3B8', textAlign: 'center', marginTop: 10 }}>
          Nenhuma atividade registrada recentemente.
        </Text>
      ) : (
        atividades.map((atividade, index) => {
          // Verifica se é entrada ou saída para 
          const ehEntrada = atividade.tipo === 'entrada';

          return (
            <View key={atividade.id || index} style={styles.activityCard}>
              <Ionicons
                name={ehEntrada ? "checkmark-circle" : "remove-circle"}
                size={22}
                color={ehEntrada ? "#22C55E" : "#EF4444"}
              />
              <Text style={styles.activityText}>
                {ehEntrada ? 'Entrada' : 'Saída'} de {atividade.quantidade}x {atividade.produto_nome}
              </Text>
            </View>
          );
        })
      )}

      <View style={{ height: 40 }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#020617',
    paddingHorizontal: 20,
  },
  header: {
    marginTop: 60,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  welcome: {
    color: '#94A3B8',
    fontSize: 15,
  },
  userName: {
    color: '#fff',
    fontSize: 28,
    fontWeight: 'bold',
    marginTop: 3,
  },
  notification: {
    width: 50,
    height: 50,
    backgroundColor: '#1E293B',
    borderRadius: 15,
    justifyContent: 'center',
    alignItems: 'center',
  },
  balanceCard: {
    backgroundColor: '#0fb5aa',
    borderRadius: 30,
    padding: 25,
    marginTop: 30,
  },
  balanceLabel: {
    color: '#000000',
    fontSize: 16,
  },
  balanceValue: {
    color: '#fff',
    fontSize: 42,
    fontWeight: 'bold',
    marginTop: 10,
  },
  balanceFooter: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 12,
  },
  balanceGrowth: {
    color: '#DCFCE7',
    marginLeft: 6,
    fontWeight: '600',
  },
  cardsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 25,
  },
  smallCard: {
    backgroundColor: '#04928b',
    width: '48%',
    borderRadius: 22,
    padding: 20,
  },
  iconBlue: {
    width: 50,
    height: 50,
    backgroundColor: '#172554',
    borderRadius: 15,
    justifyContent: 'center',
    alignItems: 'center',
  },
  iconRed: {
    width: 50,
    height: 50,
    backgroundColor: '#450A0A',
    borderRadius: 15,
    justifyContent: 'center',
    alignItems: 'center',
  },
  cardNumber: {
    color: '#fff',
    fontSize: 28,
    fontWeight: 'bold',
    marginTop: 15,
  },
  cardLabel: {
    color: '#000000',
    marginTop: 5,
  },
  sectionTitle: {
    color: '#fff',
    fontSize: 22,
    fontWeight: 'bold',
    marginTop: 35,
    marginBottom: 18,
  },
  actionButtonBlue: {
    backgroundColor: '#2563EB',
    borderRadius: 24,
    padding: 20,
    marginBottom: 15,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  actionButtonYellow: {
    backgroundColor: '#EAB308',
    borderRadius: 24,
    padding: 20,
    marginBottom: 15,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  actionButtonRed: {
    backgroundColor: '#DC2626',
    borderRadius: 24,
    padding: 20,
    marginBottom: 15,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  buttonContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 15,
  },
  buttonTitle: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
  buttonSubtitle: {
    color: '#E2E8F0',
    marginTop: 3,
    fontSize: 13,
  },
  activityCard: {
    backgroundColor: '#1E293B',
    borderRadius: 18,
    padding: 18,
    marginBottom: 12,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  activityText: {
    color: '#fff',
    fontSize: 15,
  },
});