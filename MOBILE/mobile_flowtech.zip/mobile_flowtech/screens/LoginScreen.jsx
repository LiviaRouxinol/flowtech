import React, { useState } from 'react';
import {
  StyleSheet,
  Text,
  View,
  TextInput,
  TouchableOpacity,
  SafeAreaView,
  Alert,
  Image
} from 'react-native';
import { MaterialIcons, FontAwesome } from '@expo/vector-icons';
import api from '../src/services/api';

export default function LoginScreen({ navigation }) {
  const [e_mail, setE_mail] = useState('');
  const [senha, setSenha] = useState('');
  const [secureText, setSecureText] = useState(true);
  const [rememberMe, setRememberMe] = useState(false);

  const handleLogin = async () => {
    if (e_mail === '' || senha === '') {
      Alert.alert('Erro', 'Por favor, preencha todos os campos!');
      return;
    }


    try {
      // 1. Envia a requisição para o servidor
      const response = await api.post('/login', { e_mail: e_mail, senha });

      console.log("RESPOSTA DO SERVIDOR:", response.data);

      // 2. SÓ entra aqui e muda de tela se o servidor responder com status de sucesso e success verdadeiro
      if (response.data && response.data.success === true) {
        navigation.navigate('App');
      } else {
        // Caso o servidor responda com status 200, mas com formato diferente ou credenciais erradas
        Alert.alert('Erro', response.data?.message || 'E-mail ou senha incorretos.');
      }

    } catch (error) {
      // ADICIONE ESTA LINHA ABAIXO TAMBÉM PARA VER SE O SERVIDOR DEVOLVEU ERRO DIRETO:
      console.log("ERRO DO SERVIDOR:", error.response?.data);

      const mensagemErro = error.response?.data?.message || 'E-mail ou senha incorretos.';
      Alert.alert('Erro de Login', mensagemErro);
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.content}>

        {/* LOGO E NOME DA MARCA */}
        <View style={styles.logoContainer}>
          <Image
            source={require('../assets/logo.png')}
            style={styles.logoImage}
            resizeMode="contain"
          />
          <Text style={styles.brandName}>FlowTech</Text>
        </View>


        {/* TEXTOS DE BOAS-VINDAS */}
        <Text style={styles.title}>Bem-vindo!</Text>
        <Text style={styles.subtitle}>Faça seu login para continuar</Text>

        {/* CAMPO DE LOGIN / EMAIL */}
        <Text style={styles.label}>Login:</Text>
        <View style={styles.inputContainer}>
          <MaterialIcons name="e_mail" size={20} color="#999" style={styles.inputIcon} />
          <TextInput
            style={styles.input}
            placeholder="Digite seu email"
            placeholderTextColor="#999"
            keyboardType="email-address"
            autoCapitalize="none"
            value={e_mail}
            onChangeText={setE_mail}
          />
        </View>

        {/* CAMPO DE SENHA */}
        <Text style={styles.label}>Senha:</Text>
        <View style={styles.inputContainer}>
          <FontAwesome name="lock" size={20} color="#999" style={styles.inputIcon} />
          <TextInput
            style={styles.input}
            placeholder="Digite sua senha"
            placeholderTextColor="#999"
            secureTextEntry={secureText}
            value={senha}
            onChangeText={setSenha}
          />
          {/* Botão do Olho com ícone verdadeiro */}
          <TouchableOpacity onPress={() => setSecureText(!secureText)}>
            <MaterialIcons
              name={secureText ? "visibility-off" : "visibility"}
              size={22}
              color="#333"
            />
          </TouchableOpacity>
        </View>

        {/* LEMBRAR DE MIM E ESQUECI MINHA SENHA */}
        <View style={styles.rowOptions}>
          <TouchableOpacity
            style={styles.checkboxContainer}
            onPress={() => setRememberMe(!rememberMe)}
          >
            <View style={[styles.checkbox, rememberMe && styles.checkboxChecked]}>
              {rememberMe && <MaterialIcons name="check" size={12} color="#0a4d52" />}
            </View>
            <Text style={styles.checkboxLabel}>Lembrar de mim</Text>
          </TouchableOpacity>

          <TouchableOpacity>
            <Text style={styles.forgotPasswordText}>Esqueci minha senha</Text>
          </TouchableOpacity>
        </View>

        {/* BOTÃO ENTRAR */}
        <TouchableOpacity style={styles.button} onPress={handleLogin}>
          <Text style={styles.buttonText}>Login</Text>
        </TouchableOpacity>

        {/* RODAPÉ: SUPORTE E TERMOS DE USO */}
        <View style={styles.footer}>
          <TouchableOpacity>
            <Text style={styles.footerLink}>suporte</Text>
          </TouchableOpacity>
          <TouchableOpacity>
            <Text style={styles.footerLink}>termos de uso</Text>
          </TouchableOpacity>
        </View>

      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000000',
  },
  content: {
    flex: 1,
    justifyContent: 'center',
    paddingHorizontal: 30,
  },
  logoContainer: {
    alignItems: 'center',
    marginBottom: 20,
  },
  logoImage: {
    width: 150,
    height: 100,
    marginBottom: 0,
  },
  brandName: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#00f7ff',

  },
  title: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#fff',
    textAlign: 'center',
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 13,
    color: '#ccc',
    textAlign: 'center',
    marginBottom: 25,
  },
  label: {
    fontSize: 14,
    color: '#fff',
    marginBottom: 5,
    alignSelf: 'flex-start',
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff',
    borderRadius: 20,
    paddingHorizontal: 12,
    marginBottom: 15,
    height: 45,
  },
  inputIcon: {
    marginRight: 8,
  },
  input: {
    flex: 1,
    height: '100%',
    color: '#333',
    fontSize: 14,
  },
  rowOptions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 35,
    marginTop: 5,
  },
  checkboxContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  checkbox: {
    width: 16,
    height: 16,
    borderWidth: 1.5,
    borderColor: '#fff',
    borderRadius: 2,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 8,
  },
  checkboxChecked: {
    backgroundColor: '#00ff51b4',
    borderColor: '#00ff51b4',
  },
  checkboxLabel: {
    color: '#fff',
    fontSize: 12,
  },
  forgotPasswordText: {
    color: '#00e5ff',
    fontSize: 12,
    textDecorationLine: 'underline',
  },
  button: {
    backgroundColor: '#00ff51b4',
    height: 48,
    borderRadius: 24,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 3,
    elevation: 3,
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    position: 'absolute',
    bottom: 30,
    left: 30,
    right: 30,
  },
  footerLink: {
    color: '#00f7ff',
    fontSize: 14,
    textDecorationLine: 'underline',
  },
});
