import React from 'react';
import { View, TouchableOpacity, StyleSheet, Text } from 'react-native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { Ionicons } from '@expo/vector-icons';

// IMPORTAÇÃO DAS SUAS TELAS
import EntryScreen from './EntryScreen';
import ExitScreen from './ExitScreen';

const InnerStack = createNativeStackNavigator();

// 1. FUNÇÃO PRINCIPAL NO TOPO (Garante que o componente existe para o App.js imediatamente)
export default function MovimentacaoScreen() {
  return (
    <InnerStack.Navigator
      screenOptions={{
        headerShown: false,
      }}
    >
      <InnerStack.Screen name="MenuMovimentacao" component={MenuMovimentacao} />
      <InnerStack.Screen name="EntryScreen" component={EntryScreen} />
      <InnerStack.Screen name="ExitScreen" component={ExitScreen} />
    </InnerStack.Navigator>
  );
}

// 2. SUB-TELA DE MENU (Declarada logo abaixo)
function MenuMovimentacao({ navigation }) {
  return (
    <View style={styles.container}>
      {/* Botão de Entrada */}
      <TouchableOpacity
        style={styles.actionButtonGreen}
        onPress={() => navigation.navigate('EntryScreen')}
      >
        <View style={styles.buttonContent}>
          <Ionicons name="arrow-down-circle-outline" size={26} color="#fff" />
          <View style={styles.textGroup}>
            <Text style={styles.buttonTitle}>Entrada de Estoque</Text>
            <Text style={styles.buttonSubtitle}>Registrar novos produtos</Text>
          </View>
        </View>
        <Ionicons name="chevron-forward" size={22} color="#fff" />
      </TouchableOpacity>

      {/* Botão de Saída */}
      <TouchableOpacity
        style={styles.actionButtonRed}
        onPress={() => navigation.navigate('ExitScreen')}
      >
        <View style={styles.buttonContent}>
          <Ionicons name="arrow-up-circle-outline" size={26} color="#fff" />
          <View style={styles.textGroup}>
            <Text style={styles.buttonTitle}>Saída de Estoque</Text>
            <Text style={styles.buttonSubtitle}>Registrar baixas do estoque</Text>
          </View>
        </View>
        <Ionicons name="chevron-forward" size={22} color="#fff" />
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#020617',
    paddingHorizontal: 20,
    justifyContent: 'center',
  },
  actionButtonGreen: {
    backgroundColor: '#16A34A',
    borderRadius: 24,
    padding: 20,
    marginBottom: 15,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  actionButtonRed: {
    backgroundColor: '#DC2626',
    borderRadius: 24,
    padding: 20,
    marginBottom: 15,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  buttonContent: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  textGroup: {
    marginLeft: 15, // Substitui o gap que podia gerar bugs de renderização
  },
  buttonTitle: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
  buttonSubtitle: {
    color: '#E2E8F0',
    marginTop: 3,
    fontSize: 13,
  },
});