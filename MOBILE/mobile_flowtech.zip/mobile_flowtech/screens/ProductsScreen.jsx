import React, { useState, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  Image,
  TextInput,
  TouchableOpacity,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useFocusEffect } from '@react-navigation/native';
import api from '../src/services/api';

export default function ProductsScreen() {
  const [search, setSearch] = useState('');
  const [produto, setProducts] = useState([]);

  const loadProducts = async () => {
    try {
      // Ajustado de forma inteligente para tentar ambas as configurações de baseURL do axios
      const response = await api.get('/produto').catch(() => api.get('/api/produto'));
      setProducts(response.data || []);
    } catch (error) {
      console.log('Erro ao buscar produtos:', error);
    }
  };

  useFocusEffect(
    useCallback(() => {
      loadProducts();
    }, [])
  );

  // Filtro atualizado para as propriedades em Português
  const filteredProducts = Array.isArray(produto)
    ? produto.filter(
        (item) =>
          item.nome?.toLowerCase().includes(search.toLowerCase()) ||
          item.categoria?.toLowerCase().includes(search.toLowerCase())
      )
    : [];

  return (
    <View style={styles.container}>

      {/* CABEÇALHO */}
      <View style={styles.header}>
        <View>
          <Text style={styles.title}>Produtos</Text>
          <Text style={styles.subtitle}>Consulte os produtos cadastrados</Text>
        </View>

        <TouchableOpacity style={styles.filterButton}>
          <Ionicons name="options-outline" size={24} color="#FFFFFF" />
        </TouchableOpacity>
      </View>

      {/* PESQUISA */}
      <View style={styles.searchContainer}>
        <Ionicons name="search-outline" size={22} color="#007E83" />
        <TextInput
          style={styles.searchInput}
          placeholder="Pesquisar produtos..."
          placeholderTextColor="#94A3B8"
          value={search}
          onChangeText={setSearch}
        />
      </View>

      {/* LISTA DE PRODUTOS */}
      <FlatList
        data={filteredProducts}
        keyExtractor={(item) => item.id?.toString() || Math.random().toString()}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: 40 }}
        
        ListEmptyComponent={() => (
          <View style={{ alignItems: 'center', marginTop: 40 }}>
            <Ionicons name="alert-circle-outline" size={40} color="#94A3B8" />
            <Text style={{ color: '#64748B', marginTop: 10, fontSize: 16 }}>
              Nenhum produto encontrado.
            </Text>
          </View>
        )}

        renderItem={({ item }) => (
          <View style={styles.card}>
            <Image
              source={{ uri: item.image || 'https://placeholder.com' }}
              style={styles.image}
            />

            <View style={styles.content}>
              {/* NOME + ESTOQUE */}
              <View style={styles.topRow}>
                <View style={{ flex: 1 }}>
                  <Text style={styles.name}>{item.nome}</Text>
                  <Text style={styles.category}>{item.categoria}</Text>
                </View>

                <View
                  style={[
                    styles.stockBadge,
                    { backgroundColor: Number(item.estoque || 0) <= 5 ? '#DC2626' : '#007E83' },
                  ]}
                >
                  <Text style={styles.stockText}>{item.estoque ?? 0}</Text>
                </View>
              </View>

              {/* INFORMAÇÕES */}
              <View style={styles.infoRow}>
                <View style={styles.infoCard}>
                  <Ionicons name="cube-outline" size={18} color="#007E83" />
                  <Text style={styles.infoText}>Estoque</Text>
                </View>

                <View style={styles.infoCard}>
                  <Ionicons name="barcode-outline" size={18} color="#007E83" />
                  <Text style={styles.infoText}>{item.codigo || 'S/C'}</Text>
                </View>
              </View>

              {/* PREÇO + STATUS */}
              <View style={styles.bottomRow}>
                <Text style={styles.price}>R$ {Number(item.preco || 0).toFixed(2)}</Text>
                <Text
                  style={[
                    styles.stockStatus,
                    { color: Number(item.estoque || 0) <= 5 ? '#DC2626' : '#007E83' },
                  ]}
                >
                  {Number(item.estoque || 0) <= 5 ? 'Estoque baixo' : 'Disponível'}
                </Text>
              </View>
            </View>
          </View>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F5F9F9', paddingHorizontal: 20 },
  header: { marginTop: 55, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 25 },
  title: { color: '#0F172A', fontSize: 32, fontWeight: 'bold' },
  subtitle: { color: '#64748B', marginTop: 5, fontSize: 15 },
  filterButton: { width: 52, height: 52, backgroundColor: '#007E83', borderRadius: 18, justifyContent: 'center', alignItems: 'center', elevation: 4 },
  searchContainer: { backgroundColor: '#FFFFFF', height: 62, borderRadius: 20, flexDirection: 'row', alignItems: 'center', paddingHorizontal: 18, marginBottom: 25, borderWidth: 1, borderColor: '#DCE7E7', elevation: 2 },
  searchInput: { flex: 1, marginLeft: 10, color: '#0F172A', fontSize: 16 },
  card: { backgroundColor: '#FFFFFF', borderRadius: 28, overflow: 'hidden', marginBottom: 22, borderWidth: 1, borderColor: '#E2EEEE', elevation: 3 },
  image: { width: '100%', height: 220, backgroundColor: '#EAF4F4' },
  content: { padding: 20 },
  topRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' },
  name: { color: '#0F172A', fontSize: 21, fontWeight: 'bold' },
  category: { color: '#64748B', marginTop: 6, fontSize: 15 },
  stockBadge: { minWidth: 48, height: 48, borderRadius: 16, justifyContent: 'center', alignItems: 'center', paddingHorizontal: 12 },
  stockText: { color: '#FFFFFF', fontSize: 16, fontWeight: 'bold' },
  infoRow: { flexDirection: 'row', marginTop: 18, gap: 12 },
  infoCard: { backgroundColor: '#EFF7F7', borderRadius: 14, paddingHorizontal: 14, paddingVertical: 10, flexDirection: 'row', alignItems: 'center' },
  infoText: { color: '#475569', marginLeft: 8, fontSize: 13, fontWeight: '500' },
  bottomRow: { marginTop: 22, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  price: { color: '#007E83', fontSize: 26, fontWeight: 'bold' },
  stockStatus: { fontSize: 14, fontWeight: '600' },
});