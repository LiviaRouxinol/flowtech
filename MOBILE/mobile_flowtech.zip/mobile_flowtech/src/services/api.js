import axios from 'axios';

const api = axios.create({
  baseURL: 'http://10.135.60.73:3000/', // Substitua pelo seu IP Local
});

export default api;